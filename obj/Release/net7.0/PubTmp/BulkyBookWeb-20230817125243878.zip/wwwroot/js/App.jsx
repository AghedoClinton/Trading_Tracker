﻿class App extends React.Component {
    render() {
        return (
            <div className="commotBox"> This is a trading strategies website</div>

        );
    }
}

ReactDOM.render(<App />, document.getElementById('root'));